from ._spoutgl.enums import *
